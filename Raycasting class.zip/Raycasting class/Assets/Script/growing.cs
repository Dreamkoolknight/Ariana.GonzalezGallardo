﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class growing : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//Widen the object by 1
		transform.localScale += new Vector3(1f,1,1);
	}
	
	// Update is called once per frame
	void Update () {
	}
}
