using System.Collections;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class laser : MonoBehaviour
{
    public GameObject blueprint;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Ray laser = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hit = new RaycastHit();

        if (Physics.Raycast(laser, out hit, 1000f)) && Input.GetMouseButton(0){
            Component.GetComponent<AudioSource>().Play();
            Debug.Log("you done hit something");

            if (hit.rigidbody)
            {
                hit.rigibody.Addforce(Random.insideUnitSphere * 999f);

                if (hit.gameobject.GetComponent<AudioSource>())
                {
                    hit.gameobject.GetComponent<AudioSource>().Play();
                }
            }
        } else {
            GetComponet<AudioSource>().Stop();
        }
        (Input.GetMouseButton(1)){
            Instantiate(blueprint, hit point, Quaternion.identity);
        }
    }
        if (Physics.Raycast(laser,out hit,1000f)) &using UnityEngine;

public class laser : MonoBehaviour
{
    public GameObject blueprint;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Ray laser = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hit = new RaycastHit();

        if (Physics.Raycast(laser, out hit, 1000f)) && Input.GetMouseButton(0){
            Component.GetComponent<AudioSource>().Play();
            Debug.Log("you done hit something");

            if (hit.rigidbody)
            {
                hit.rigibody.Addforce(Random.insideUnitSphere * 999f);

                if (hit.gameobject.GetComponent<AudioSource>())
                {
                    hit.gameobject.GetComponent<AudioSource>().Play();
                }
            }
        } else {
            GetComponet<AudioSource>().Stop();
        }
        (Input.GetMouseButton(1)){
            Instantiate(blueprint, hit point, Quaternion.identity);
        }
    }
        if (Physics.Raycast(laser,out hit,1000f)) &

        